import {
  createCipheriv,
  createDecipheriv,
  createHmac,
  createHash,
} from "node:crypto";

const SECRET = process.env["SESSION_SECRET"] ?? "dev-secret-change-me";
const KEY = createHash("sha256").update(SECRET).digest();

const DEFAULT_TTL_MS = 6 * 60 * 60 * 1000;
const BUCKET_MS = 30 * 60 * 1000;

export interface EncryptedPayload {
  url: string;
  serverId: string;
}

function deriveIv(url: string, serverId: string, expBucket: number): Buffer {
  return createHmac("sha256", KEY)
    .update(`${serverId}|${expBucket}|${url}`)
    .digest()
    .subarray(0, 12);
}

export function encryptUrl(
  url: string,
  serverId: string,
  ttlMs: number = DEFAULT_TTL_MS,
): string {
  const exp = Math.ceil((Date.now() + ttlMs) / BUCKET_MS) * BUCKET_MS;
  const iv = deriveIv(url, serverId, exp);
  const cipher = createCipheriv("aes-256-gcm", KEY, iv);
  const payload = JSON.stringify({ u: url, s: serverId, e: exp });
  const encrypted = Buffer.concat([
    cipher.update(payload, "utf8"),
    cipher.final(),
  ]);
  const tag = cipher.getAuthTag();
  const combined = Buffer.concat([iv, tag, encrypted]);
  return combined.toString("base64url");
}

export function decryptUrl(token: string): EncryptedPayload | null {
  try {
    const combined = Buffer.from(token, "base64url");
    if (combined.length < 28) return null;
    const iv = combined.subarray(0, 12);
    const tag = combined.subarray(12, 28);
    const encrypted = combined.subarray(28);
    const decipher = createDecipheriv("aes-256-gcm", KEY, iv);
    decipher.setAuthTag(tag);
    const decrypted = Buffer.concat([
      decipher.update(encrypted),
      decipher.final(),
    ]);
    const payload = JSON.parse(decrypted.toString("utf8")) as {
      u: string;
      s: string;
      e: number;
    };
    if (Date.now() > payload.e) return null;
    return { url: payload.u, serverId: payload.s };
  } catch {
    return null;
  }
}

export function checkAdminPassword(provided: string | undefined): boolean {
  if (!provided) return false;
  const expected = process.env["ADMIN_PASSWORD"] ?? SECRET;
  if (provided.length !== expected.length) return false;
  let mismatch = 0;
  for (let i = 0; i < provided.length; i++) {
    mismatch |= provided.charCodeAt(i) ^ expected.charCodeAt(i);
  }
  return mismatch === 0;
}
