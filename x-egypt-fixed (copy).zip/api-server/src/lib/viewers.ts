const TTL_MS = 30_000;

const sessions = new Map<string, Map<string, number>>();

function pruneInactive(map: Map<string, number>): number {
  const cutoff = Date.now() - TTL_MS;
  for (const [id, ts] of map) {
    if (ts < cutoff) map.delete(id);
  }
  return map.size;
}

export function pingViewer(serverId: string, sessionId: string): number {
  let map = sessions.get(serverId);
  if (!map) {
    map = new Map();
    sessions.set(serverId, map);
  }
  map.set(sessionId, Date.now());
  return pruneInactive(map);
}

export function leaveViewer(serverId: string, sessionId: string): number {
  const map = sessions.get(serverId);
  if (!map) return 0;
  map.delete(sessionId);
  return pruneInactive(map);
}

export function getViewerCount(serverId: string): number {
  const map = sessions.get(serverId);
  if (!map) return 0;
  return pruneInactive(map);
}

export function getAllCounts(): Record<string, number> {
  const result: Record<string, number> = {};
  for (const [serverId, map] of sessions) {
    result[serverId] = pruneInactive(map);
  }
  return result;
}

setInterval(() => {
  for (const [, map] of sessions) pruneInactive(map);
}, 15_000).unref?.();
