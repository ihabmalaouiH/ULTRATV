import {
  readFileSync,
  writeFileSync,
  existsSync,
  mkdirSync,
} from "node:fs";
import path from "node:path";
import { logger } from "./logger";

export interface StreamServer {
  id: string;
  name: string;
  url: string;
  drmKeys?: Record<string, string>;
  referer?: string;
  origin?: string;
  userAgent?: string;
  headers?: Record<string, string>;
}

export interface PublicServer {
  id: string;
  name: string;
}

const DATA_DIR = path.resolve(process.cwd(), "data");
const SERVERS_FILE = path.join(DATA_DIR, "servers.json");

let servers: StreamServer[] = [];

function ensureDir(): void {
  if (!existsSync(DATA_DIR)) {
    mkdirSync(DATA_DIR, { recursive: true });
  }
}

function persist(): void {
  ensureDir();
  writeFileSync(SERVERS_FILE, JSON.stringify(servers, null, 2), "utf8");
}

function seed(): void {
  servers = [
    {
      id: "demo-bbb",
      name: "بث تجريبي - استبدله من لوحة الإدارة",
      url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
    },
  ];
  persist();
}

export function loadServers(): void {
  ensureDir();
  if (existsSync(SERVERS_FILE)) {
    try {
      const raw = readFileSync(SERVERS_FILE, "utf8");
      servers = JSON.parse(raw) as StreamServer[];
      logger.info({ count: servers.length }, "Loaded servers");
      return;
    } catch (err) {
      logger.error({ err }, "Failed to load servers, reseeding");
    }
  }
  seed();
}

export function listPublicServers(): PublicServer[] {
  return servers.map((s) => ({ id: s.id, name: s.name }));
}

export function listAdminServers(): StreamServer[] {
  return [...servers];
}

export function getServerById(id: string): StreamServer | undefined {
  return servers.find((s) => s.id === id);
}

export function upsertServer(server: StreamServer): void {
  const idx = servers.findIndex((s) => s.id === server.id);
  if (idx >= 0) {
    servers[idx] = server;
  } else {
    servers.push(server);
  }
  persist();
}

export function deleteServer(id: string): boolean {
  const before = servers.length;
  servers = servers.filter((s) => s.id !== id);
  const removed = servers.length < before;
  if (removed) persist();
  return removed;
}

loadServers();
