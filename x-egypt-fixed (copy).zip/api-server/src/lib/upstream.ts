import type { StreamServer } from "./servers";

const DEFAULT_UA =
  "Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";

export function buildUpstreamHeaders(
  server: StreamServer,
): Record<string, string> {
  const headers: Record<string, string> = {
    "User-Agent": server.userAgent ?? DEFAULT_UA,
    Accept: "*/*",
    "Accept-Language": "en-US,en;q=0.9,ar;q=0.8",
  };
  if (server.referer) headers["Referer"] = server.referer;
  if (server.origin) headers["Origin"] = server.origin;
  if (server.headers) Object.assign(headers, server.headers);
  return headers;
}

export type StreamKind = "hls" | "dash" | "raw";

export interface ResolvedStream {
  url: string;
  kind: StreamKind;
}

function detectKindFromUrl(url: string): StreamKind | null {
  if (url.includes(".m3u8")) return "hls";
  if (url.includes(".mpd")) return "dash";
  return null;
}

function detectKindFromContent(
  contentType: string,
  body: string,
): StreamKind | null {
  const ct = contentType.toLowerCase();
  if (
    ct.includes("mpegurl") ||
    ct.includes("x-mpegurl") ||
    body.startsWith("#EXTM3U")
  ) {
    return "hls";
  }
  if (
    ct.includes("dash+xml") ||
    body.includes("<MPD")
  ) {
    return "dash";
  }
  return null;
}

interface CacheEntry {
  resolved: ResolvedStream;
  expires: number;
}
const resolveCache = new Map<string, CacheEntry>();
const CACHE_TTL_MS = 60_000;

export function clearResolveCache(serverId?: string): void {
  if (serverId) resolveCache.delete(serverId);
  else resolveCache.clear();
}

export async function resolveStreamUrl(
  server: StreamServer,
): Promise<ResolvedStream> {
  const cached = resolveCache.get(server.id);
  if (cached && cached.expires > Date.now()) {
    return cached.resolved;
  }

  let url = server.url;

  const directKind = detectKindFromUrl(url);
  if (directKind) {
    const result: ResolvedStream = { url, kind: directKind };
    resolveCache.set(server.id, {
      resolved: result,
      expires: Date.now() + CACHE_TTL_MS,
    });
    return result;
  }

  try {
    const res = await fetch(url, {
      headers: buildUpstreamHeaders(server),
      redirect: "follow",
    });

    const finalUrl = res.url || url;
    const ct = res.headers.get("content-type") ?? "";

    // Try JSON first
    if (ct.includes("json")) {
      const data = (await res.json()) as Record<string, unknown>;
      const candidates = [
        "channelUrl",
        "url",
        "stream",
        "manifest",
        "src",
        "playlist",
      ];
      for (const key of candidates) {
        const value = data[key];
        if (typeof value === "string" && value.startsWith("http")) {
          const k = detectKindFromUrl(value);
          return { url: value, kind: k ?? "raw" };
        }
      }
      return { url: finalUrl, kind: "raw" };
    }

    // Read a small portion to detect M3U8 / MPD signatures
    const text = await res.text();
    const peek = text.slice(0, 200).trim();

    const kindFromContent = detectKindFromContent(ct, peek);
    if (kindFromContent) {
      const result: ResolvedStream = { url: finalUrl, kind: kindFromContent };
      resolveCache.set(server.id, {
        resolved: result,
        expires: Date.now() + CACHE_TTL_MS,
      });
      return result;
    }

    const kindFromFinalUrl = detectKindFromUrl(finalUrl);
    if (kindFromFinalUrl) {
      const result: ResolvedStream = { url: finalUrl, kind: kindFromFinalUrl };
      resolveCache.set(server.id, {
        resolved: result,
        expires: Date.now() + CACHE_TTL_MS,
      });
      return result;
    }

    return { url: finalUrl, kind: "raw" };
  } catch {
    return { url, kind: detectKindFromUrl(url) ?? "raw" };
  }
}
