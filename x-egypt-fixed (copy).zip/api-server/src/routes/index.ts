import { Router, type IRouter } from "express";
import healthRouter from "./health";
import streamsRouter from "./streams";
import adminRouter from "./admin";
import viewersRouter from "./viewers";

const router: IRouter = Router();

router.use(healthRouter);
router.use(streamsRouter);
router.use(adminRouter);
router.use(viewersRouter);

export default router;
