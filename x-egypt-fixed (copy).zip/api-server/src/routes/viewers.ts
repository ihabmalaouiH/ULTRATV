import { Router, type IRouter, type Request } from "express";
import {
  pingViewer,
  leaveViewer,
  getViewerCount,
  getAllCounts,
} from "../lib/viewers";

const router: IRouter = Router();

function strParam(req: Request, key: string): string {
  const v = (req.params as Record<string, unknown>)[key];
  return typeof v === "string" ? v : "";
}

function strBody(req: Request, key: string): string {
  const v = (req.body as Record<string, unknown> | undefined)?.[key];
  return typeof v === "string" ? v : "";
}

router.post("/viewers/:serverId/ping", (req, res) => {
  const serverId = strParam(req, "serverId");
  const sessionId = strBody(req, "sessionId");
  if (!serverId || !sessionId) {
    res.status(400).json({ error: "missing fields" });
    return;
  }
  const count = pingViewer(serverId, sessionId);
  res.setHeader("Cache-Control", "no-store");
  res.json({ count });
});

router.post("/viewers/:serverId/leave", (req, res) => {
  const serverId = strParam(req, "serverId");
  const sessionId = strBody(req, "sessionId");
  if (serverId && sessionId) leaveViewer(serverId, sessionId);
  res.json({ ok: true });
});

router.get("/viewers/:serverId", (req, res) => {
  const serverId = strParam(req, "serverId");
  res.setHeader("Cache-Control", "no-store");
  res.json({ count: getViewerCount(serverId) });
});

router.get("/viewers", (_req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.json({ counts: getAllCounts() });
});

export default router;
