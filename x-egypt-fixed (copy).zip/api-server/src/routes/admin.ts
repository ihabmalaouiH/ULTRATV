import {
  Router,
  type IRouter,
  type Request,
  type Response,
  type NextFunction,
} from "express";
import {
  listAdminServers,
  upsertServer,
  deleteServer,
  type StreamServer,
} from "../lib/servers";
import { checkAdminPassword } from "../lib/crypto";
import { clearResolveCache } from "../lib/upstream";

const router: IRouter = Router();

function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  const header = req.headers["x-admin-password"];
  const password = Array.isArray(header) ? header[0] : header;
  if (!checkAdminPassword(password)) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
}

router.post("/admin/login", (req, res) => {
  const password =
    typeof req.body?.password === "string" ? req.body.password : "";
  if (!checkAdminPassword(password)) {
    res.status(401).json({ ok: false, error: "كلمة المرور غير صحيحة" });
    return;
  }
  res.json({ ok: true });
});

router.get("/admin/servers", requireAdmin, (_req, res) => {
  res.json({ servers: listAdminServers() });
});

function sanitizeServer(input: unknown): StreamServer | null {
  if (!input || typeof input !== "object") return null;
  const obj = input as Record<string, unknown>;
  const id = typeof obj["id"] === "string" ? obj["id"].trim() : "";
  const name = typeof obj["name"] === "string" ? obj["name"].trim() : "";
  const url = typeof obj["url"] === "string" ? obj["url"].trim() : "";
  if (!id || !name || !url) return null;

  const result: StreamServer = { id, name, url };
  if (
    obj["drmKeys"] &&
    typeof obj["drmKeys"] === "object" &&
    !Array.isArray(obj["drmKeys"])
  ) {
    const map: Record<string, string> = {};
    for (const [k, v] of Object.entries(obj["drmKeys"])) {
      if (typeof v === "string" && v.length > 0) {
        map[k.toLowerCase().replace(/[^0-9a-f]/g, "")] = v
          .toLowerCase()
          .replace(/[^0-9a-f]/g, "");
      }
    }
    if (Object.keys(map).length > 0) result.drmKeys = map;
  }
  if (typeof obj["referer"] === "string" && obj["referer"].trim())
    result.referer = obj["referer"].trim();
  if (typeof obj["origin"] === "string" && obj["origin"].trim())
    result.origin = obj["origin"].trim();
  if (typeof obj["userAgent"] === "string" && obj["userAgent"].trim())
    result.userAgent = obj["userAgent"].trim();
  if (
    obj["headers"] &&
    typeof obj["headers"] === "object" &&
    !Array.isArray(obj["headers"])
  ) {
    const map: Record<string, string> = {};
    for (const [k, v] of Object.entries(obj["headers"])) {
      if (typeof v === "string") map[k] = v;
    }
    if (Object.keys(map).length > 0) result.headers = map;
  }
  return result;
}

router.post("/admin/servers", requireAdmin, (req, res) => {
  const server = sanitizeServer(req.body);
  if (!server) {
    res
      .status(400)
      .json({ error: "البيانات غير مكتملة - مطلوب: id, name, url" });
    return;
  }
  upsertServer(server);
  clearResolveCache(server.id);
  res.json({ ok: true, server });
});

router.delete("/admin/servers/:id", requireAdmin, (req, res) => {
  const id = typeof req.params.id === "string" ? req.params.id : "";
  clearResolveCache(id);
  const removed = deleteServer(id);
  if (!removed) {
    res.status(404).json({ error: "السيرفر غير موجود" });
    return;
  }
  res.json({ ok: true });
});

export default router;
