import { Router, type IRouter, type Request, type Response } from "express";
import { Readable } from "node:stream";
import {
  listPublicServers,
  getServerById,
} from "../lib/servers";
import { encryptUrl, decryptUrl } from "../lib/crypto";
import { buildUpstreamHeaders, resolveStreamUrl } from "../lib/upstream";

const router: IRouter = Router();

const SEG_CACHE = "public, max-age=8, s-maxage=12, stale-while-revalidate=20";
const M3U8_CACHE = "public, max-age=2, s-maxage=2";
const MPD_CACHE = "public, max-age=2, s-maxage=2";

router.get("/servers", (_req, res) => {
  res.json({ servers: listPublicServers() });
});

function paramId(req: Request, key: string): string {
  const v = (req.params as Record<string, unknown>)[key];
  return typeof v === "string" ? v : "";
}

router.get("/streams/:id/manifest", async (req: Request, res: Response) => {
  const server = getServerById(paramId(req, "id"));
  if (!server) {
    res.status(404).json({ error: "Server not found" });
    return;
  }

  try {
    const resolved = await resolveStreamUrl(server);
    const type =
      resolved.kind === "hls"
        ? "hls"
        : resolved.kind === "dash"
          ? "dash"
          : "auto";

    const token = encryptUrl(resolved.url, server.id);
    const ext =
      resolved.kind === "hls"
        ? "m3u8"
        : resolved.kind === "dash"
          ? "mpd"
          : "raw";
    const manifestUrl = `/api/proxy/${ext}/${token}`;

    const hasDrm = !!server.drmKeys && Object.keys(server.drmKeys).length > 0;
    const licenseUrl = hasDrm ? `/api/streams/${server.id}/license` : null;

    res.json({
      manifestUrl,
      type,
      licenseUrl,
      hasDrm,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to build manifest");
    res.status(502).json({ error: "Upstream resolve failed" });
  }
});

function jwkLicenseResponse(drmKeys: Record<string, string>): {
  keys: { kty: string; k: string; kid: string }[];
  type: string;
} {
  const toBase64Url = (hex: string): string =>
    Buffer.from(hex, "hex").toString("base64url");
  const keys = Object.entries(drmKeys).map(([kid, key]) => ({
    kty: "oct",
    kid: toBase64Url(kid),
    k: toBase64Url(key),
  }));
  return { keys, type: "temporary" };
}

router.get("/streams/:id/license", (req, res) => {
  const server = getServerById(req.params.id ?? "");
  if (!server || !server.drmKeys) {
    res.status(404).json({ error: "No license" });
    return;
  }
  res.setHeader("Cache-Control", "no-store");
  res.json(jwkLicenseResponse(server.drmKeys));
});

router.post("/streams/:id/license", (req, res) => {
  const server = getServerById(req.params.id ?? "");
  if (!server || !server.drmKeys) {
    res.status(404).json({ error: "No license" });
    return;
  }
  res.setHeader("Cache-Control", "no-store");
  res.json(jwkLicenseResponse(server.drmKeys));
});

function rewriteM3u8(text: string, baseUrl: URL, serverId: string): string {
  return text
    .split("\n")
    .map((line) => {
      const trimmed = line.trim();
      if (!trimmed) return line;

      if (trimmed.startsWith("#")) {
        return line.replace(/URI="([^"]+)"/g, (_match, uri: string) => {
          const absolute = new URL(uri, baseUrl).toString();
          const ext = absolute.includes(".m3u8") ? "m3u8" : "seg";
          const token = encryptUrl(absolute, serverId);
          return `URI="/api/proxy/${ext}/${token}"`;
        });
      }

      const absolute = new URL(trimmed, baseUrl).toString();
      const ext = absolute.includes(".m3u8") ? "m3u8" : "seg";
      const token = encryptUrl(absolute, serverId);
      return `/api/proxy/${ext}/${token}`;
    })
    .join("\n");
}

router.get("/proxy/m3u8/:token", async (req, res) => {
  const payload = decryptUrl(req.params.token ?? "");
  if (!payload) {
    res.status(403).send("Forbidden");
    return;
  }
  const server = getServerById(payload.serverId);
  if (!server) {
    res.status(404).send("Server not found");
    return;
  }

  try {
    const upstream = await fetch(payload.url, {
      headers: buildUpstreamHeaders(server),
    });
    if (!upstream.ok) {
      res.status(upstream.status).send("Upstream error");
      return;
    }
    const text = await upstream.text();
    const baseUrl = new URL(payload.url);
    const rewritten = rewriteM3u8(text, baseUrl, server.id);

    res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
    res.setHeader("Cache-Control", M3U8_CACHE);
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.send(rewritten);
  } catch (err) {
    req.log.error({ err }, "Proxy m3u8 error");
    res.status(502).send("Bad gateway");
  }
});

router.get("/proxy/mpd/:token", async (req, res) => {
  const payload = decryptUrl(req.params.token ?? "");
  if (!payload) {
    res.status(403).send("Forbidden");
    return;
  }
  const server = getServerById(payload.serverId);
  if (!server) {
    res.status(404).send("Server not found");
    return;
  }

  try {
    const upstream = await fetch(payload.url, {
      headers: buildUpstreamHeaders(server),
    });
    if (!upstream.ok) {
      res.status(upstream.status).send("Upstream error");
      return;
    }
    let text = await upstream.text();
    const url = new URL(payload.url);
    const baseDir =
      url.origin + url.pathname.substring(0, url.pathname.lastIndexOf("/") + 1);

    const baseToken = encryptUrl(baseDir, server.id);
    const proxyBase = `/api/proxy/dash-base/${baseToken}/`;

    text = text.replace(/<BaseURL[^>]*>[^<]*<\/BaseURL>/g, "");
    text = text.replace(
      /(<MPD[^>]*>)/,
      `$1<BaseURL>${proxyBase}</BaseURL>`,
    );

    res.setHeader("Content-Type", "application/dash+xml");
    res.setHeader("Cache-Control", MPD_CACHE);
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.send(text);
  } catch (err) {
    req.log.error({ err }, "Proxy mpd error");
    res.status(502).send("Bad gateway");
  }
});

function mimeFromUrl(url: string, fallback: string): string {
  const path = url.split("?")[0]?.toLowerCase() ?? "";
  if (path.endsWith(".ts")) return "video/mp2t";
  if (path.endsWith(".m4s")) return "video/iso.segment";
  if (path.endsWith(".mp4")) return "video/mp4";
  if (path.endsWith(".m4a")) return "audio/mp4";
  if (path.endsWith(".aac")) return "audio/aac";
  if (path.endsWith(".webm")) return "video/webm";
  if (path.endsWith(".vtt")) return "text/vtt";
  if (path.endsWith(".key")) return "application/octet-stream";
  return fallback;
}

async function pipeUpstream(
  upstreamUrl: string,
  server: Parameters<typeof buildUpstreamHeaders>[0],
  req: Request,
  res: Response,
): Promise<void> {
  const headers = buildUpstreamHeaders(server);
  const range = req.headers["range"];
  if (typeof range === "string") headers["range"] = range;

  const upstream = await fetch(upstreamUrl, { headers });
  if (!upstream.ok && upstream.status !== 206) {
    res.status(upstream.status).end();
    return;
  }
  const upstreamCT =
    upstream.headers.get("content-type") ?? "application/octet-stream";
  // 🔥 Override Content-Type if upstream returns a generic/wrong type for media
  const isGenericCT =
    upstreamCT.startsWith("text/plain") ||
    upstreamCT.startsWith("application/octet-stream") ||
    upstreamCT.startsWith("text/html") ||
    upstreamCT.startsWith("binary/octet-stream");
  const ct = isGenericCT ? mimeFromUrl(upstreamUrl, upstreamCT) : upstreamCT;

  const len = upstream.headers.get("content-length");
  const cr = upstream.headers.get("content-range");
  const ar = upstream.headers.get("accept-ranges");

  res.status(upstream.status);
  res.setHeader("Content-Type", ct);
  res.setHeader("Cache-Control", SEG_CACHE);
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "range, content-type, accept",
  );
  res.setHeader("Access-Control-Expose-Headers", "content-length, content-range");
  if (len) res.setHeader("Content-Length", len);
  if (cr) res.setHeader("Content-Range", cr);
  if (ar) res.setHeader("Accept-Ranges", ar);

  if (!upstream.body) {
    res.end();
    return;
  }
  const nodeStream = Readable.fromWeb(
    upstream.body as Parameters<typeof Readable.fromWeb>[0],
  );
  nodeStream.on("error", () => {
    if (!res.headersSent) res.status(502);
    res.end();
  });
  res.on("close", () => {
    nodeStream.destroy();
  });
  nodeStream.pipe(res);
}

router.get("/proxy/seg/:token", async (req, res) => {
  const payload = decryptUrl(req.params.token ?? "");
  if (!payload) {
    res.status(403).send("Forbidden");
    return;
  }
  const server = getServerById(payload.serverId);
  if (!server) {
    res.status(404).send("Server not found");
    return;
  }
  try {
    await pipeUpstream(payload.url, server, req, res);
  } catch (err) {
    req.log.error({ err }, "Proxy seg error");
    res.status(502).end();
  }
});

router.get("/proxy/raw/:token", async (req, res) => {
  const payload = decryptUrl(req.params.token ?? "");
  if (!payload) {
    res.status(403).send("Forbidden");
    return;
  }
  const server = getServerById(payload.serverId);
  if (!server) {
    res.status(404).send("Server not found");
    return;
  }
  try {
    await pipeUpstream(payload.url, server, req, res);
  } catch (err) {
    req.log.error({ err }, "Proxy raw error");
    res.status(502).end();
  }
});

router.use("/proxy/dash-base/:token", async (req, res) => {
  const payload = decryptUrl(req.params.token ?? "");
  if (!payload) {
    res.status(403).send("Forbidden");
    return;
  }
  const server = getServerById(payload.serverId);
  if (!server) {
    res.status(404).send("Server not found");
    return;
  }
  const subPath = req.path.replace(/^\//, "");
  const queryIdx = req.originalUrl.indexOf("?");
  const query = queryIdx >= 0 ? req.originalUrl.substring(queryIdx) : "";
  const target = payload.url + subPath + query;
  try {
    await pipeUpstream(target, server, req, res);
  } catch (err) {
    req.log.error({ err }, "Proxy dash-base error");
    res.status(502).end();
  }
});

export default router;
