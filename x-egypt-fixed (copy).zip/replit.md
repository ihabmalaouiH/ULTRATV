# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

## X EGYPT Player

Arabic-language live-stream player web app with strong server URL protection.

### Artifacts
- `artifacts/api-server` — Express 5 backend, JSON-persisted server registry, encrypted-URL stream proxy, ClearKey license endpoint, password-protected admin API.
- `artifacts/player` — React + Vite + Shaka Player frontend, dark Facebook-style UI, RTL Arabic, multi-server picker, follow-page CTA, admin panel.

### Stream protection
- All upstream HLS/DASH manifest + segment URLs are encrypted with AES-256-GCM (key derived from `SESSION_SECRET`) and exposed only as opaque tokens under `/api/proxy/*`.
- Manifests are fetched server-side, parsed, and rewritten so every nested URL is also tokenized — original origins never appear in the browser.
- DRM ClearKey JWK responses are served from `/api/streams/:id/license` so raw keys are never bundled into the client config.
- Tokens use **deterministic AES-GCM** (IV = HMAC(SECRET, serverId|expBucket|url)). Same upstream URL yields the same token within a 30-minute bucket — this lets Cloudflare/CDN cache segments across all viewers (massive bandwidth savings).
- Tokens carry an expiry (6h default, bucketed to 30-minute boundaries).

### Scaling / load handling
- **Segment proxy streams (no buffering)**: uses `Readable.fromWeb()` + `pipe()` so memory usage is constant per request regardless of segment size.
- **Range request forwarding**: `Range`/`Content-Range`/`Accept-Ranges` are passed through, enabling seek and partial fetches.
- **Cache-friendly headers**:
  - Segments (`/api/proxy/seg|raw|dash-base/*`): `public, max-age=8, s-maxage=12, stale-while-revalidate=20`
  - HLS playlist (`/api/proxy/m3u8/*`): `public, max-age=2, s-maxage=2`
  - DASH manifest (`/api/proxy/mpd/*`): `public, max-age=2, s-maxage=2`
- With Cloudflare in front (Proxied DNS, default cache rules), a single 1080p stream with 1000 viewers sends ~10 segment fetches/sec to origin instead of 1000.
- 60s in-memory cache for resolved upstream URLs, invalidated on admin upsert/delete.

### Server registry
- Stored in `artifacts/api-server/data/servers.json` (auto-seeded on first run).
- Manage via `/admin` page in the player app. Password = `ADMIN_PASSWORD` env var (or falls back to `SESSION_SECRET`).
- Each server: `id`, `name`, `url` (M3U8 / MPD / API JSON returning `channelUrl`), optional `drmKeys`, optional upstream `referer` / `origin` / `userAgent` / `headers`.

### Player features
- Auto-detects HLS vs DASH from upstream content type.
- Quality menu (auto + manual heights), live-edge button, double-tap ±10s seek, PiP, fullscreen, fit/fill/stretch toggle.
- Branding (channel name, follow-page URL/label) configured in `artifacts/player/src/config/branding.ts`.
- Smooth server switching: single Shaka instance reused via `player.unload()` + `player.load()` (no React remount). 60s server-side cache for resolved upstream URLs invalidated on admin upsert/delete.

### Real viewer counter
- Each client generates a `sessionStorage` UUID and POSTs to `/api/viewers/:serverId/ping` every 12s.
- Server stores `serverId → Map<sessionId, lastSeen>` in memory; sessions older than 30s are pruned.
- `sendBeacon` to `/api/viewers/:serverId/leave` on tab unload for immediate decrement.
- Header shows count formatted as raw / `1.2K` / `1.5M` / `1.1B`.

### Hidden admin access
- No admin gear icon in the UI. The `/admin` URL still works (login form gated by `ADMIN_PASSWORD`).
- Easter-egg: tap the "X" header logo 5 times within 2 seconds to navigate to `/admin`.

### Anti-source-stealing
- Right-click disabled on the player container (`onContextMenu` blocker).
- `controlsList="nodownload noremoteplayback"` on `<video>`.
- All real stream URLs/keys are server-side only — the browser only ever sees opaque proxy tokens.
- Vite production build is minified with no source maps.
