export const branding = {
  channelName: "X EGYPT",
  channelTag: "بث مباشر",
  pageUrl: "https://www.facebook.com/stingweb.eg",
  pageLabel: "تابع صفحتنا",
  logoText: "X",
};
