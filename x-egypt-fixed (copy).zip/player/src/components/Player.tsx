import { useEffect, useRef, useState, useCallback } from "react";
import shaka from "shaka-player/dist/shaka-player.compiled";
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Settings,
  Maximize,
  Minimize,
  PictureInPicture2,
  Radio,
  AlertTriangle,
  RotateCcw,
  RefreshCw,
} from "lucide-react";
import type { ManifestResponse } from "@/lib/api";

interface PlayerProps {
  manifest: ManifestResponse;
  serverName: string;
  onRetry: () => void;
}

interface QualityTrack {
  id: number;
  height: number | null;
  bandwidth: number;
  active: boolean;
}

interface SeekFeedback {
  direction: "forward" | "backward";
  amount: number;
  side: "left" | "right";
  key: number;
}

const HIDE_CONTROLS_DELAY = 3000;

function formatTime(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return "00:00";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  const pad = (n: number) => String(n).padStart(2, "0");
  return h > 0 ? `${pad(h)}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
}

export function Player({ manifest, serverName, onRetry }: PlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const playerRef = useRef<shaka.Player | null>(null);
  const initializedRef = useRef(false);
  const hideTimerRef = useRef<number | null>(null);
  const tapTimerRef = useRef<number | null>(null);
  const lastTapRef = useRef<{ time: number; side: "left" | "right" } | null>(
    null,
  );

  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(true);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showControls, setShowControls] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isPip, setIsPip] = useState(false);
  const [isLive, setIsLive] = useState(false);
  const [isBehindLive, setIsBehindLive] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [qualities, setQualities] = useState<QualityTrack[]>([]);
  const [autoQuality, setAutoQuality] = useState(true);
  const [activeQualityHeight, setActiveQualityHeight] = useState<number | null>(
    null,
  );
  const [showQualityMenu, setShowQualityMenu] = useState(false);
  const [seekFeedback, setSeekFeedback] = useState<SeekFeedback | null>(null);
  const [objectFitMode, setObjectFitMode] = useState<
    "contain" | "cover" | "fill"
  >("contain");

  const showControlsBriefly = useCallback(() => {
    setShowControls(true);
    if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
    const video = videoRef.current;
    if (video && !video.paused) {
      hideTimerRef.current = window.setTimeout(() => {
        setShowControls(false);
        setShowQualityMenu(false);
      }, HIDE_CONTROLS_DELAY);
    }
  }, []);

  const updateQualities = useCallback(() => {
    const player = playerRef.current;
    if (!player) return;
    try {
      const config = player.getConfiguration();
      setAutoQuality(config.abr.enabled);
      const tracks = player.getVariantTracks();
      const seen = new Map<number, QualityTrack>();
      let activeHeight: number | null = null;
      tracks.forEach((t) => {
        const height = t.height ?? null;
        if (t.active && height !== null) activeHeight = height;
        if (height !== null && !seen.has(height)) {
          seen.set(height, {
            id: t.id,
            height,
            bandwidth: t.bandwidth,
            active: t.active,
          });
        }
      });
      setActiveQualityHeight(activeHeight);
      const list = Array.from(seen.values()).sort(
        (a, b) => (b.height ?? 0) - (a.height ?? 0),
      );
      setQualities(list);
    } catch {
      // ignore
    }
  }, []);

  // Initialize Shaka ONCE on mount
  useEffect(() => {
    const video = videoRef.current;
    if (!video || initializedRef.current) return;

    shaka.polyfill.installAll();
    if (!shaka.Player.isBrowserSupported()) {
      setError("المتصفح غير مدعوم. الرجاء استخدام متصفح حديث.");
      setLoading(false);
      return;
    }

    const player = new shaka.Player();
    playerRef.current = player;
    initializedRef.current = true;

    player.attach(video).catch(() => {});

    player.configure({
      manifest: { dash: { ignoreMinBufferTime: true } },
      streaming: {
        rebufferingGoal: 1,
        bufferingGoal: 8,
        bufferBehind: 30,
        lowLatencyMode: true,
      },
      abr: { enabled: true, defaultBandwidthEstimate: 3_000_000 },
    });

    const onError = (event: shaka.util.Error) => {
      const detail = (event as unknown as { detail?: { message?: string } })
        .detail;
      const msg = detail?.message ?? "حدث خطأ أثناء التشغيل";
      setError(msg);
      setLoading(false);
    };
    const onBuffering = (event: { buffering: boolean }) =>
      setLoading(event.buffering);
    const onTracksChanged = () => updateQualities();
    const onAdaptation = () => updateQualities();

    player.addEventListener("error", onError as unknown as EventListener);
    player.addEventListener(
      "buffering",
      onBuffering as unknown as EventListener,
    );
    player.addEventListener(
      "trackschanged",
      onTracksChanged as unknown as EventListener,
    );
    player.addEventListener(
      "adaptation",
      onAdaptation as unknown as EventListener,
    );

    return () => {
      if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
      player.destroy().catch(() => {});
      playerRef.current = null;
      initializedRef.current = false;
    };
  }, [updateQualities]);

  // Load manifest whenever it changes (without recreating the player)
  useEffect(() => {
    const player = playerRef.current;
    const video = videoRef.current;
    if (!player || !video) return;

    const localPlayer = player;
    let cancelled = false;
    setLoading(true);
    setError(null);
    setQualities([]);
    setShowQualityMenu(false);

    const drmConfig: Record<string, unknown> = {};
    if (manifest.hasDrm && manifest.licenseUrl) {
      drmConfig["servers"] = {
        "org.w3.clearkey": manifest.licenseUrl,
      };
    } else {
      drmConfig["servers"] = {};
    }
    localPlayer.configure({ drm: drmConfig });

    const isStillActive = () =>
      !cancelled && playerRef.current === localPlayer;

    (async () => {
      try {
        try {
          await localPlayer.unload();
        } catch {
          // ignore unload race
        }
        if (!isStillActive()) return;

        const absoluteUrl = new URL(
          manifest.manifestUrl,
          window.location.origin,
        ).toString();
        await localPlayer.load(absoluteUrl);
        if (!isStillActive()) return;

        setLoading(false);
        setIsLive(localPlayer.isLive());
        updateQualities();
        video.muted = true;
        setMuted(true);
        try {
          await video.play();
        } catch {
          // autoplay blocked
        }
        showControlsBriefly();
      } catch (err) {
        if (!isStillActive()) return;
        const code = (err as { code?: number })?.code ?? 0;
        if (code === 7000 || code === 7002 || code === 7003) {
          return;
        }
        const msg =
          (err as { message?: string })?.message ??
          (code ? `Shaka error ${code}` : "خطأ في التحميل");
        setError(`فشل تحميل البث: ${msg}`);
        setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [
    manifest.manifestUrl,
    manifest.licenseUrl,
    manifest.hasDrm,
    showControlsBriefly,
    updateQualities,
  ]);

  // Video event listeners
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const onPlay = () => {
      setPlaying(true);
      showControlsBriefly();
    };
    const onPause = () => {
      setPlaying(false);
      setShowControls(true);
      if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
    };
    const onVolume = () => setMuted(video.muted || video.volume === 0);
    const onTimeUpdate = () => {
      const player = playerRef.current;
      if (!player) return;
      try {
        const range = player.seekRange();
        if (!Number.isFinite(range.end)) return;
        if (player.isLive()) {
          setIsLive(true);
          const behind = video.paused || range.end - video.currentTime > 15;
          setIsBehindLive(behind);
        } else if (range.end > 0) {
          setIsLive(false);
          const span = range.end - range.start;
          const elapsed = video.currentTime - range.start;
          setProgress(span > 0 ? (elapsed / span) * 100 : 0);
          setCurrentTime(elapsed);
          setDuration(span);
        }
      } catch {
        // ignore
      }
    };
    const onEnterPip = () => setIsPip(true);
    const onLeavePip = () => setIsPip(false);

    video.addEventListener("play", onPlay);
    video.addEventListener("pause", onPause);
    video.addEventListener("volumechange", onVolume);
    video.addEventListener("timeupdate", onTimeUpdate);
    video.addEventListener("enterpictureinpicture", onEnterPip);
    video.addEventListener("leavepictureinpicture", onLeavePip);

    return () => {
      video.removeEventListener("play", onPlay);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("volumechange", onVolume);
      video.removeEventListener("timeupdate", onTimeUpdate);
      video.removeEventListener("enterpictureinpicture", onEnterPip);
      video.removeEventListener("leavepictureinpicture", onLeavePip);
    };
  }, [showControlsBriefly]);

  // Fullscreen tracking
  useEffect(() => {
    const onFsChange = () =>
      setIsFullscreen(document.fullscreenElement !== null);
    document.addEventListener("fullscreenchange", onFsChange);
    return () => document.removeEventListener("fullscreenchange", onFsChange);
  }, []);

  const togglePlay = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) void video.play();
    else video.pause();
    showControlsBriefly();
  }, [showControlsBriefly]);

  const toggleMute = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = !video.muted;
    if (!video.muted && video.volume === 0) video.volume = 1;
    showControlsBriefly();
  }, [showControlsBriefly]);

  const toggleFullscreen = useCallback(async () => {
    const container = containerRef.current;
    if (!container) return;
    if (!document.fullscreenElement) {
      await container.requestFullscreen();
    } else {
      await document.exitFullscreen();
    }
  }, []);

  const togglePip = useCallback(async () => {
    const video = videoRef.current;
    if (!video) return;
    if (document.pictureInPictureElement) {
      await document.exitPictureInPicture();
    } else if (document.pictureInPictureEnabled) {
      await video.requestPictureInPicture();
    }
  }, []);

  const cycleObjectFit = useCallback(() => {
    setObjectFitMode((prev) =>
      prev === "contain" ? "cover" : prev === "cover" ? "fill" : "contain",
    );
    showControlsBriefly();
  }, [showControlsBriefly]);

  const seekRelative = useCallback(
    (seconds: number, side: "left" | "right") => {
      const video = videoRef.current;
      const player = playerRef.current;
      if (!video || !player) return;
      try {
        if (player.isLive()) {
          const range = player.seekRange();
          const target = Math.min(
            range.end,
            Math.max(range.start, video.currentTime + seconds),
          );
          video.currentTime = target;
        } else {
          video.currentTime = Math.max(0, video.currentTime + seconds);
        }
      } catch {
        // ignore
      }
      setSeekFeedback({
        direction: seconds > 0 ? "forward" : "backward",
        amount: Math.abs(seconds),
        side,
        key: Date.now(),
      });
      window.setTimeout(() => setSeekFeedback(null), 600);
    },
    [],
  );

  const goLive = useCallback(() => {
    const video = videoRef.current;
    const player = playerRef.current;
    if (!video || !player || !player.isLive()) return;
    const range = player.seekRange();
    video.currentTime = range.end;
  }, []);

  const handleProgressClick = useCallback((e: React.MouseEvent) => {
    const video = videoRef.current;
    const player = playerRef.current;
    if (!video || !player || player.isLive()) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = (e.clientX - rect.left) / rect.width;
    const range = player.seekRange();
    video.currentTime = range.start + ratio * (range.end - range.start);
  }, []);

  const handleVideoTap = useCallback(
    (e: React.MouseEvent | React.TouchEvent) => {
      const target = e.target as HTMLElement;
      if (target.closest("button") || target.closest(".fb-controls"))
        return;
      const container = containerRef.current;
      if (!container) return;
      const rect = container.getBoundingClientRect();
      const x =
        "touches" in e
          ? (e.touches[0]?.clientX ?? e.changedTouches[0]?.clientX ?? 0)
          : e.clientX;
      const relX = x - rect.left;
      const side: "left" | "right" =
        relX < rect.width / 2 ? "left" : "right";

      const now = Date.now();
      const last = lastTapRef.current;
      if (last && now - last.time < 300 && last.side === side) {
        if (tapTimerRef.current) {
          window.clearTimeout(tapTimerRef.current);
          tapTimerRef.current = null;
        }
        lastTapRef.current = null;
        if (side === "left") seekRelative(-10, "left");
        else seekRelative(10, "right");
        return;
      }
      lastTapRef.current = { time: now, side };
      if (tapTimerRef.current) window.clearTimeout(tapTimerRef.current);
      tapTimerRef.current = window.setTimeout(() => {
        if (showControls) {
          setShowControls(false);
          setShowQualityMenu(false);
        } else {
          showControlsBriefly();
        }
        lastTapRef.current = null;
        tapTimerRef.current = null;
      }, 280);
    },
    [seekRelative, showControls, showControlsBriefly],
  );

  const selectQuality = useCallback((track: QualityTrack | null) => {
    const player = playerRef.current;
    if (!player) return;
    if (track === null) {
      player.configure({ abr: { enabled: true } });
      setAutoQuality(true);
    } else {
      player.configure({ abr: { enabled: false } });
      const variants = player.getVariantTracks();
      const match = variants.find((v) => v.height === track.height);
      if (match) player.selectVariantTrack(match, true);
      setAutoQuality(false);
      setActiveQualityHeight(track.height);
    }
    setShowQualityMenu(false);
  }, []);

  const blockContextMenu = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
  }, []);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full bg-black overflow-hidden no-tap-highlight"
      onMouseMove={showControlsBriefly}
      onClick={handleVideoTap}
      onTouchStart={handleVideoTap}
      onContextMenu={blockContextMenu}
      data-testid="player-container"
    >
      <video
        ref={videoRef}
        className="w-full h-full"
        style={{ objectFit: objectFitMode, background: "#000" }}
        playsInline
        autoPlay
        muted
        controlsList="nodownload noremoteplayback"
        disablePictureInPicture={false}
      />

      {loading && !error && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30">
          <div className="fb-spinner" />
        </div>
      )}

      {error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/90 z-40 px-6 text-center">
          <AlertTriangle className="w-14 h-14 text-red-500 mb-4" />
          <h3 className="text-white text-xl font-bold mb-2">فشل تحميل البث</h3>
          <p className="text-gray-300 text-sm mb-6 max-w-md">{error}</p>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onRetry();
            }}
            className="flex items-center gap-2 bg-[#1877f2] hover:bg-[#1664d8] text-white px-6 py-3 rounded-lg font-semibold transition"
            data-testid="button-retry"
          >
            <RefreshCw className="w-5 h-5" />
            إعادة المحاولة
          </button>
        </div>
      )}

      {seekFeedback && (
        <div
          className="fb-seek-feedback"
          key={seekFeedback.key}
          style={{ [seekFeedback.side]: "15%" }}
        >
          {seekFeedback.direction === "backward" ? (
            <RotateCcw className="w-8 h-8" />
          ) : (
            <RotateCcw
              className="w-8 h-8"
              style={{ transform: "scaleX(-1)" }}
            />
          )}
          <span className="text-sm mt-1">{seekFeedback.amount}ث</span>
        </div>
      )}

      <div
        className={`fb-controls absolute top-0 left-0 right-0 px-4 py-3 z-20 transition-opacity ${
          showControls ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
        style={{
          background:
            "linear-gradient(180deg, rgba(0,0,0,0.85) 0%, transparent 100%)",
        }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {isLive && (
              <div className="flex items-center gap-2">
                <span className="fb-live-pulse w-2 h-2 rounded-full bg-red-600" />
                <span className="text-white text-sm font-bold">LIVE</span>
              </div>
            )}
          </div>
          <div className="text-white text-sm font-medium opacity-90 truncate max-w-[60%] text-center">
            {serverName}
          </div>
          <div className="w-12" />
        </div>
      </div>

      {!playing && !loading && !error && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            togglePlay();
          }}
          className="fb-controls absolute inset-0 flex items-center justify-center z-20"
          data-testid="button-center-play"
        >
          <div className="bg-black/60 rounded-full p-5 backdrop-blur hover:bg-black/80 transition fb-fade-in">
            <Play className="w-12 h-12 text-white" fill="white" />
          </div>
        </button>
      )}

      <div
        className={`fb-controls absolute bottom-0 left-0 right-0 z-20 transition-opacity ${
          showControls ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
        style={{
          background:
            "linear-gradient(0deg, rgba(0,0,0,0.85) 0%, transparent 100%)",
        }}
      >
        {!isLive && duration > 0 && (
          <div
            className="px-4 pt-3 pb-1 cursor-pointer group"
            onClick={(e) => {
              e.stopPropagation();
              handleProgressClick(e);
            }}
          >
            <div className="fb-progress-track h-1 group-hover:h-1.5 rounded-full transition-all relative">
              <div
                className="fb-progress-fill h-full rounded-full transition-all"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        {isLive && (
          <div className="px-4 pt-3 pb-1">
            <div className="bg-red-600 h-1 rounded-full" />
          </div>
        )}

        <div className="flex items-center justify-between px-4 py-3" dir="ltr">
          <div className="flex items-center gap-3">
            <button
              onClick={(e) => {
                e.stopPropagation();
                togglePlay();
              }}
              className="text-white hover:text-blue-400 transition p-1"
              title={playing ? "إيقاف" : "تشغيل"}
              data-testid="button-play-pause"
            >
              {playing ? (
                <Pause className="w-6 h-6" fill="currentColor" />
              ) : (
                <Play className="w-6 h-6" fill="currentColor" />
              )}
            </button>

            <button
              onClick={(e) => {
                e.stopPropagation();
                toggleMute();
              }}
              className="text-white hover:text-blue-400 transition p-1"
              title={muted ? "تشغيل الصوت" : "كتم"}
              data-testid="button-mute"
            >
              {muted ? (
                <VolumeX className="w-6 h-6" />
              ) : (
                <Volume2 className="w-6 h-6" />
              )}
            </button>

            <div className="text-white text-xs font-medium tabular-nums">
              {isLive ? (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (isBehindLive) goLive();
                  }}
                  className={`px-2 py-1 rounded text-white text-xs font-bold transition ${
                    isBehindLive
                      ? "bg-gray-600 hover:bg-red-600 cursor-pointer"
                      : "bg-red-600"
                  }`}
                  data-testid="button-live"
                >
                  ● {isBehindLive ? "العودة للمباشر" : "مباشر"}
                </button>
              ) : (
                <span>
                  {formatTime(currentTime)} / {formatTime(duration)}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3 relative">
            {qualities.length > 0 && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowQualityMenu((v) => !v);
                }}
                className="text-white hover:text-blue-400 transition p-1 flex items-center gap-1"
                title="الجودة"
                data-testid="button-quality"
              >
                <Settings className="w-5 h-5" />
                <span className="text-xs font-bold">
                  {autoQuality
                    ? "تلقائي"
                    : activeQualityHeight
                      ? `${activeQualityHeight}p`
                      : ""}
                </span>
              </button>
            )}

            <button
              onClick={(e) => {
                e.stopPropagation();
                cycleObjectFit();
              }}
              className="text-white hover:text-blue-400 transition p-1 text-xs font-bold"
              title="وضع العرض"
              data-testid="button-fit"
            >
              {objectFitMode === "contain"
                ? "FIT"
                : objectFitMode === "cover"
                  ? "FILL"
                  : "STRETCH"}
            </button>

            {document.pictureInPictureEnabled && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  void togglePip();
                }}
                className="text-white hover:text-blue-400 transition p-1"
                title="نافذة منبثقة"
                data-testid="button-pip"
              >
                <PictureInPicture2
                  className="w-5 h-5"
                  fill={isPip ? "currentColor" : "none"}
                />
              </button>
            )}

            <button
              onClick={(e) => {
                e.stopPropagation();
                void toggleFullscreen();
              }}
              className="text-white hover:text-blue-400 transition p-1"
              title="ملء الشاشة"
              data-testid="button-fullscreen"
            >
              {isFullscreen ? (
                <Minimize className="w-5 h-5" />
              ) : (
                <Maximize className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>

        {showQualityMenu && qualities.length > 0 && (
          <div
            className="fb-glass absolute bottom-16 right-4 rounded-lg p-2 min-w-[160px] fb-fade-in border border-white/10 z-30"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              className={`w-full text-right px-3 py-2 rounded-md text-sm font-medium transition flex items-center justify-between ${
                autoQuality
                  ? "bg-[#1877f2] text-white"
                  : "text-white hover:bg-white/10"
              }`}
              onClick={() => selectQuality(null)}
              data-testid="quality-auto"
            >
              <span>تلقائي</span>
              {autoQuality && <Radio className="w-4 h-4" />}
            </button>
            {qualities.map((q) => (
              <button
                key={q.id}
                className={`w-full text-right px-3 py-2 rounded-md text-sm font-medium transition flex items-center justify-between ${
                  !autoQuality && activeQualityHeight === q.height
                    ? "bg-[#1877f2] text-white"
                    : "text-white hover:bg-white/10"
                }`}
                onClick={() => selectQuality(q)}
                data-testid={`quality-${q.height}`}
              >
                <span>{q.height}p</span>
                {!autoQuality && activeQualityHeight === q.height && (
                  <Radio className="w-4 h-4" />
                )}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
