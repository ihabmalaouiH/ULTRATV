import { useEffect, useState, useCallback } from "react";
import { Link } from "wouter";
import {
  Lock,
  ArrowRight,
  Plus,
  Trash2,
  Save,
  Server as ServerIcon,
  Key,
  Globe,
  X,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
import {
  adminLogin,
  fetchAdminServers,
  saveAdminServer,
  deleteAdminServer,
  type AdminServer,
} from "@/lib/api";

interface FormState {
  id: string;
  name: string;
  url: string;
  drmKid: string;
  drmKey: string;
  referer: string;
  origin: string;
  userAgent: string;
}

const emptyForm: FormState = {
  id: "",
  name: "",
  url: "",
  drmKid: "",
  drmKey: "",
  referer: "",
  origin: "",
  userAgent: "",
};

function serverToForm(s: AdminServer): FormState {
  const firstKid = s.drmKeys ? Object.keys(s.drmKeys)[0] ?? "" : "";
  const firstKey = firstKid && s.drmKeys ? (s.drmKeys[firstKid] ?? "") : "";
  return {
    id: s.id,
    name: s.name,
    url: s.url,
    drmKid: firstKid,
    drmKey: firstKey,
    referer: s.referer ?? "",
    origin: s.origin ?? "",
    userAgent: s.userAgent ?? "",
  };
}

function formToServer(f: FormState): AdminServer | string {
  if (!f.id.trim()) return "المعرّف مطلوب";
  if (!f.name.trim()) return "اسم السيرفر مطلوب";
  if (!f.url.trim()) return "الرابط مطلوب";

  const result: AdminServer = {
    id: f.id.trim().toLowerCase().replace(/\s+/g, "-"),
    name: f.name.trim(),
    url: f.url.trim(),
  };
  if (f.drmKid.trim() && f.drmKey.trim()) {
    result.drmKeys = {
      [f.drmKid.trim().toLowerCase().replace(/[^0-9a-f]/g, "")]: f.drmKey
        .trim()
        .toLowerCase()
        .replace(/[^0-9a-f]/g, ""),
    };
  }
  if (f.referer.trim()) result.referer = f.referer.trim();
  if (f.origin.trim()) result.origin = f.origin.trim();
  if (f.userAgent.trim()) result.userAgent = f.userAgent.trim();
  return result;
}

export function AdminPage() {
  const [authed, setAuthed] = useState(false);
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);

  const [servers, setServers] = useState<AdminServer[]>([]);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [showForm, setShowForm] = useState(false);
  const [toast, setToast] = useState<{
    type: "success" | "error";
    msg: string;
  } | null>(null);

  useEffect(() => {
    const stored = sessionStorage.getItem("admin_password");
    if (stored) {
      setAuthed(true);
    }
  }, []);

  const showToast = useCallback(
    (type: "success" | "error", msg: string) => {
      setToast({ type, msg });
      window.setTimeout(() => setToast(null), 2500);
    },
    [],
  );

  const loadServers = useCallback(async () => {
    setLoading(true);
    try {
      const list = await fetchAdminServers();
      setServers(list);
    } catch {
      sessionStorage.removeItem("admin_password");
      setAuthed(false);
      showToast("error", "انتهت الجلسة. أعد تسجيل الدخول");
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    if (authed) void loadServers();
  }, [authed, loadServers]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoginLoading(true);
    try {
      const ok = await adminLogin(password);
      if (!ok) {
        setLoginError("كلمة المرور غير صحيحة");
        return;
      }
      sessionStorage.setItem("admin_password", password);
      setAuthed(true);
    } catch {
      setLoginError("تعذّر الاتصال بالسيرفر");
    } finally {
      setLoginLoading(false);
    }
  };

  const handleNew = () => {
    setForm(emptyForm);
    setEditingId(null);
    setShowForm(true);
  };

  const handleEdit = (s: AdminServer) => {
    setForm(serverToForm(s));
    setEditingId(s.id);
    setShowForm(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const result = formToServer(form);
    if (typeof result === "string") {
      showToast("error", result);
      return;
    }
    try {
      await saveAdminServer(result);
      showToast("success", "تم الحفظ بنجاح");
      setShowForm(false);
      setForm(emptyForm);
      setEditingId(null);
      await loadServers();
    } catch (err) {
      showToast("error", err instanceof Error ? err.message : "فشل الحفظ");
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("هل تريد حذف هذا السيرفر؟")) return;
    try {
      await deleteAdminServer(id);
      showToast("success", "تم الحذف");
      await loadServers();
    } catch {
      showToast("error", "فشل الحذف");
    }
  };

  if (!authed) {
    return (
      <div
        className="min-h-screen bg-background flex items-center justify-center px-4"
        dir="rtl"
      >
        <div className="bg-card border border-border rounded-2xl p-6 w-full max-w-sm shadow-2xl">
          <div className="flex flex-col items-center mb-6">
            <div className="w-14 h-14 rounded-full bg-[#1877f2] flex items-center justify-center mb-3">
              <Lock className="w-7 h-7 text-white" />
            </div>
            <h2 className="text-xl font-bold text-foreground">لوحة الإدارة</h2>
            <p className="text-muted-foreground text-sm mt-1">
              أدخل كلمة المرور للمتابعة
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-3">
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="كلمة المرور"
              className="w-full px-4 py-3 bg-input border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-[#1877f2]"
              required
              data-testid="input-admin-password"
              autoFocus
            />
            {loginError && (
              <p className="text-red-500 text-sm flex items-center gap-1">
                <AlertCircle className="w-4 h-4" />
                {loginError}
              </p>
            )}
            <button
              type="submit"
              disabled={loginLoading}
              className="w-full bg-[#1877f2] hover:bg-[#1664d8] text-white py-3 rounded-lg font-bold transition disabled:opacity-50"
              data-testid="button-admin-login"
            >
              {loginLoading ? "جاري الدخول..." : "دخول"}
            </button>
          </form>

          <div className="mt-4 pt-4 border-t border-border">
            <Link
              href="/"
              className="text-muted-foreground text-sm flex items-center gap-1 hover:text-foreground"
              data-testid="link-back-to-player"
            >
              <ArrowRight className="w-4 h-4" />
              العودة للمشغل
            </Link>
          </div>

          <div className="mt-3 text-xs text-muted-foreground text-center">
            كلمة المرور الافتراضية: قيمة <code>SESSION_SECRET</code> أو
            <code> ADMIN_PASSWORD</code>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      <header className="bg-card border-b border-border sticky top-0 z-20">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link
              href="/"
              className="text-muted-foreground hover:text-foreground p-2 hover-elevate rounded-lg"
              data-testid="link-back"
            >
              <ArrowRight className="w-5 h-5" />
            </Link>
            <div>
              <h1 className="text-foreground font-bold">إدارة السيرفرات</h1>
              <p className="text-muted-foreground text-xs">
                {servers.length} سيرفر مضاف
              </p>
            </div>
          </div>
          <button
            onClick={handleNew}
            className="bg-[#1877f2] hover:bg-[#1664d8] text-white px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2"
            data-testid="button-add-server"
          >
            <Plus className="w-4 h-4" />
            إضافة سيرفر
          </button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-4 space-y-3">
        {loading ? (
          <div className="text-center py-12 text-muted-foreground">
            جاري التحميل...
          </div>
        ) : servers.length === 0 ? (
          <div className="bg-card rounded-xl border border-border p-12 text-center">
            <ServerIcon className="w-16 h-16 mx-auto text-muted-foreground mb-3" />
            <h3 className="text-foreground font-bold text-lg mb-1">
              لا توجد سيرفرات
            </h3>
            <p className="text-muted-foreground text-sm mb-4">
              ابدأ بإضافة أول سيرفر للبث
            </p>
            <button
              onClick={handleNew}
              className="bg-[#1877f2] hover:bg-[#1664d8] text-white px-5 py-2 rounded-lg font-bold inline-flex items-center gap-2"
              data-testid="button-add-first"
            >
              <Plus className="w-4 h-4" />
              إضافة الآن
            </button>
          </div>
        ) : (
          servers.map((s) => (
            <div
              key={s.id}
              className="bg-card border border-border rounded-xl p-4"
              data-testid={`server-card-${s.id}`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-bold text-foreground truncate">
                      {s.name}
                    </h3>
                    {s.drmKeys && (
                      <span
                        className="bg-green-500/10 text-green-500 text-xs px-2 py-0.5 rounded-full flex items-center gap-1"
                        title="DRM ClearKey"
                      >
                        <Key className="w-3 h-3" />
                        DRM
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground font-mono truncate">
                    {s.id}
                  </p>
                  <p className="text-xs text-muted-foreground/70 truncate mt-1">
                    {s.url}
                  </p>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleEdit(s)}
                    className="px-3 py-1.5 bg-secondary text-secondary-foreground rounded-md text-sm hover-elevate"
                    data-testid={`button-edit-${s.id}`}
                  >
                    تعديل
                  </button>
                  <button
                    onClick={() => handleDelete(s.id)}
                    className="p-1.5 text-red-500 hover:bg-red-500/10 rounded-md"
                    data-testid={`button-delete-${s.id}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </main>

      {/* Form modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-40 flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-card border-b border-border px-5 py-3 flex items-center justify-between">
              <h2 className="font-bold text-foreground">
                {editingId ? "تعديل السيرفر" : "إضافة سيرفر جديد"}
              </h2>
              <button
                onClick={() => setShowForm(false)}
                className="p-1.5 hover-elevate rounded-lg text-muted-foreground"
                data-testid="button-close-form"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 space-y-4">
              <Field
                label="معرّف السيرفر (بالإنجليزية، بدون مسافات)"
                required
                value={form.id}
                onChange={(v) => setForm({ ...form, id: v })}
                placeholder="server-1"
                disabled={!!editingId}
                testId="input-server-id"
              />
              <Field
                label="اسم العرض (بالعربية)"
                required
                value={form.name}
                onChange={(v) => setForm({ ...form, name: v })}
                placeholder="السيرفر الأول - HD"
                testId="input-server-name"
              />
              <Field
                label="رابط البث (M3U8 / MPD / API JSON)"
                required
                value={form.url}
                onChange={(v) => setForm({ ...form, url: v })}
                placeholder="https://example.com/stream.m3u8"
                hint="يدعم: m3u8 (HLS) / mpd (DASH) / رابط JSON يحتوي channelUrl"
                testId="input-server-url"
              />

              <details className="bg-secondary/50 rounded-lg p-3 group">
                <summary className="cursor-pointer font-semibold text-sm text-foreground flex items-center gap-2">
                  <Key className="w-4 h-4 text-[#1877f2]" />
                  مفاتيح التشفير DRM (اختياري)
                </summary>
                <div className="mt-3 space-y-3">
                  <Field
                    label="Key ID (KID)"
                    value={form.drmKid}
                    onChange={(v) => setForm({ ...form, drmKid: v })}
                    placeholder="462b64d0595b3838b4d68eb0e6c59448"
                    testId="input-drm-kid"
                  />
                  <Field
                    label="Key"
                    value={form.drmKey}
                    onChange={(v) => setForm({ ...form, drmKey: v })}
                    placeholder="b4d30d1bfe81d4cffc52790bb6c5d979"
                    testId="input-drm-key"
                  />
                </div>
              </details>

              <details className="bg-secondary/50 rounded-lg p-3 group">
                <summary className="cursor-pointer font-semibold text-sm text-foreground flex items-center gap-2">
                  <Globe className="w-4 h-4 text-[#1877f2]" />
                  هيدرات الطلب (اختياري)
                </summary>
                <div className="mt-3 space-y-3">
                  <Field
                    label="Referer"
                    value={form.referer}
                    onChange={(v) => setForm({ ...form, referer: v })}
                    placeholder="https://example.com/"
                    testId="input-referer"
                  />
                  <Field
                    label="Origin"
                    value={form.origin}
                    onChange={(v) => setForm({ ...form, origin: v })}
                    placeholder="https://example.com"
                    testId="input-origin"
                  />
                  <Field
                    label="User-Agent"
                    value={form.userAgent}
                    onChange={(v) => setForm({ ...form, userAgent: v })}
                    placeholder="Mozilla/5.0..."
                    testId="input-user-agent"
                  />
                </div>
              </details>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="px-4 py-2 bg-secondary text-secondary-foreground rounded-lg font-medium hover-elevate"
                  data-testid="button-cancel"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#1877f2] hover:bg-[#1664d8] text-white rounded-lg font-bold flex items-center gap-2"
                  data-testid="button-save"
                >
                  <Save className="w-4 h-4" />
                  حفظ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div
          className={`fixed bottom-4 left-1/2 -translate-x-1/2 px-4 py-3 rounded-lg shadow-2xl z-50 flex items-center gap-2 fb-fade-in font-medium ${
            toast.type === "success"
              ? "bg-green-600 text-white"
              : "bg-red-600 text-white"
          }`}
        >
          {toast.type === "success" ? (
            <CheckCircle2 className="w-5 h-5" />
          ) : (
            <AlertCircle className="w-5 h-5" />
          )}
          {toast.msg}
        </div>
      )}
    </div>
  );
}

interface FieldProps {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  hint?: string;
  required?: boolean;
  disabled?: boolean;
  testId?: string;
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  hint,
  required,
  disabled,
  testId,
}: FieldProps) {
  return (
    <div>
      <label className="block text-sm font-semibold text-foreground mb-1">
        {label}
        {required && <span className="text-red-500"> *</span>}
      </label>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        disabled={disabled}
        dir="ltr"
        className="w-full px-3 py-2 bg-input border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-[#1877f2] disabled:opacity-50 font-mono text-sm"
        data-testid={testId}
      />
      {hint && (
        <p className="text-xs text-muted-foreground mt-1">{hint}</p>
      )}
    </div>
  );
}
