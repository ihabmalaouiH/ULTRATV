import { useEffect, useState, useCallback, useRef } from "react";
import {
  Facebook,
  Server as ServerIcon,
  Shield,
  Loader2,
  Eye,
} from "lucide-react";
import { Player } from "@/components/Player";
import {
  fetchServers,
  fetchManifest,
  type PublicServer,
  type ManifestResponse,
} from "@/lib/api";
import { useViewerCount, formatViewerCount } from "@/lib/viewers";
import { branding } from "@/config/branding";

const LOGO_TAP_THRESHOLD = 5;
const LOGO_TAP_WINDOW = 2000;

export function PlayerPage() {
  const [servers, setServers] = useState<PublicServer[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [manifest, setManifest] = useState<ManifestResponse | null>(null);
  const [loadingServers, setLoadingServers] = useState(true);
  const [switchingServer, setSwitchingServer] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [retryKey, setRetryKey] = useState(0);

  const logoTapsRef = useRef<number[]>([]);

  const viewerCount = useViewerCount(selectedId);

  useEffect(() => {
    let cancelled = false;
    setLoadingServers(true);
    fetchServers()
      .then((s) => {
        if (cancelled) return;
        setServers(s);
        if (s.length > 0 && !selectedId) {
          setSelectedId(s[0]!.id);
        }
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        setError(err instanceof Error ? err.message : "Failed to load servers");
      })
      .finally(() => !cancelled && setLoadingServers(false));
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!selectedId) return;
    let cancelled = false;
    setSwitchingServer(true);
    setError(null);
    fetchManifest(selectedId)
      .then((m) => {
        if (cancelled) return;
        setManifest(m);
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        setError(err instanceof Error ? err.message : "Failed to load stream");
      })
      .finally(() => !cancelled && setSwitchingServer(false));
    return () => {
      cancelled = true;
    };
  }, [selectedId, retryKey]);

  const handleRetry = useCallback(() => {
    setRetryKey((k) => k + 1);
  }, []);

  const handleSelectServer = useCallback(
    (id: string) => {
      if (id === selectedId) return;
      setSelectedId(id);
    },
    [selectedId],
  );

  // Hidden admin access: tap the X logo 5 times in 2s
  const handleLogoTap = useCallback(() => {
    const now = Date.now();
    logoTapsRef.current = [
      ...logoTapsRef.current.filter((t) => now - t < LOGO_TAP_WINDOW),
      now,
    ];
    if (logoTapsRef.current.length >= LOGO_TAP_THRESHOLD) {
      logoTapsRef.current = [];
      window.location.href = `${import.meta.env.BASE_URL.replace(/\/$/, "")}/admin`;
    }
  }, []);

  const selectedServer = servers.find((s) => s.id === selectedId);

  return (
    <div className="min-h-screen bg-background flex flex-col" dir="rtl">
      <header className="bg-card border-b border-border sticky top-0 z-30 backdrop-blur-md bg-card/95">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleLogoTap}
              className="w-10 h-10 rounded-full bg-[#1877f2] flex items-center justify-center text-white font-black text-xl shadow-lg select-none cursor-default"
              aria-label={branding.channelName}
              data-testid="logo-tap"
            >
              {branding.logoText}
            </button>
            <div>
              <h1 className="text-foreground font-bold text-lg leading-tight">
                {branding.channelName}
              </h1>
              <div className="flex items-center gap-3 text-xs">
                <span className="text-muted-foreground flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-red-500 rounded-full inline-block fb-live-pulse" />
                  {branding.channelTag}
                </span>
                {viewerCount > 0 && (
                  <span
                    className="text-muted-foreground flex items-center gap-1 fb-fade-in"
                    data-testid="viewer-count"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span className="font-semibold tabular-nums">
                      {formatViewerCount(viewerCount)}
                    </span>
                    <span>مشاهد</span>
                  </span>
                )}
              </div>
            </div>
          </div>

          <a
            href={branding.pageUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 bg-[#1877f2] hover:bg-[#1664d8] text-white px-4 py-2 rounded-full font-bold text-sm transition shadow-md hover:shadow-lg"
            data-testid="link-follow-page"
          >
            <Facebook className="w-4 h-4" fill="white" stroke="#1877f2" />
            <span className="hidden sm:inline">{branding.pageLabel}</span>
            <span className="sm:hidden">متابعة</span>
          </a>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-4 flex flex-col gap-4">
        <div
          className="relative w-full bg-black rounded-xl overflow-hidden shadow-2xl"
          style={{ aspectRatio: "16 / 9" }}
        >
          {switchingServer && !manifest && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-white gap-3 z-10">
              <Loader2 className="w-12 h-12 animate-spin text-[#1877f2]" />
              <p className="text-sm text-gray-300">جاري الاتصال بالسيرفر...</p>
            </div>
          )}

          {error && !manifest && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-white gap-3 z-10 p-6 text-center">
              <Shield className="w-14 h-14 text-red-500" />
              <p className="font-bold text-lg">تعذّر تحميل البث</p>
              <p className="text-sm text-gray-400 max-w-md">{error}</p>
              <button
                onClick={handleRetry}
                className="mt-2 bg-[#1877f2] text-white px-6 py-2 rounded-lg font-semibold hover:bg-[#1664d8]"
                data-testid="button-page-retry"
              >
                حاول مرة أخرى
              </button>
            </div>
          )}

          {manifest && selectedServer && (
            <div
              className={`absolute inset-0 transition-opacity duration-300 ${
                switchingServer ? "opacity-50" : "opacity-100"
              }`}
            >
              <Player
                manifest={manifest}
                serverName={selectedServer.name}
                onRetry={handleRetry}
              />
            </div>
          )}

          {switchingServer && manifest && (
            <div className="absolute top-4 right-4 z-30 bg-black/60 backdrop-blur rounded-full px-3 py-1.5 flex items-center gap-2 fb-fade-in">
              <Loader2 className="w-4 h-4 animate-spin text-white" />
              <span className="text-white text-xs font-medium">
                جاري التبديل...
              </span>
            </div>
          )}

          {!switchingServer && !manifest && !error && servers.length === 0 && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-white gap-3 p-6 text-center">
              <ServerIcon className="w-14 h-14 text-gray-500" />
              <p className="font-bold text-lg">لا توجد سيرفرات مضافة</p>
              <p className="text-sm text-gray-400">
                اضغط على الشعار 5 مرات للدخول للوحة الإدارة
              </p>
            </div>
          )}
        </div>

        <section className="bg-card rounded-xl border border-border p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-foreground font-bold flex items-center gap-2">
              <ServerIcon className="w-5 h-5 text-[#1877f2]" />
              اختر السيرفر
            </h2>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Shield className="w-3.5 h-3.5 text-green-500" />
              روابط محمية
            </div>
          </div>

          {loadingServers ? (
            <div className="flex items-center justify-center py-8 text-muted-foreground">
              <Loader2 className="w-5 h-5 animate-spin" />
            </div>
          ) : servers.length === 0 ? (
            <div className="text-center py-6 text-muted-foreground text-sm">
              لا توجد سيرفرات
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
              {servers.map((s, idx) => (
                <button
                  key={s.id}
                  onClick={() => handleSelectServer(s.id)}
                  className={`relative px-3 py-3 rounded-lg font-semibold text-sm transition-all border ${
                    selectedId === s.id
                      ? "bg-[#1877f2] text-white border-[#1877f2] shadow-lg shadow-blue-500/20"
                      : "bg-secondary text-secondary-foreground border-border hover-elevate"
                  }`}
                  data-testid={`button-server-${s.id}`}
                >
                  <div className="flex items-center justify-center gap-1.5">
                    <span className="text-xs opacity-70">#{idx + 1}</span>
                    <span className="truncate">{s.name}</span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </section>

        <section className="bg-card rounded-xl border border-border p-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-green-500/10 flex items-center justify-center flex-shrink-0">
                <Shield className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <p className="font-bold text-foreground">حماية كاملة</p>
                <p className="text-muted-foreground text-xs mt-0.5">
                  روابط M3U8 / TS مشفّرة ولا تظهر في المتصفح
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                <Eye className="w-5 h-5 text-[#1877f2]" />
              </div>
              <div>
                <p className="font-bold text-foreground">مشاهدات حقيقية</p>
                <p className="text-muted-foreground text-xs mt-0.5">
                  عداد لحظي للمشاهدين النشطين على كل سيرفر
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-[#1877f2]/10 flex items-center justify-center flex-shrink-0">
                <Facebook className="w-5 h-5 text-[#1877f2]" />
              </div>
              <div>
                <p className="font-bold text-foreground">تابعنا</p>
                <p className="text-muted-foreground text-xs mt-0.5">
                  ادعمنا بمتابعة صفحتنا الرسمية
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="text-center py-4 text-xs text-muted-foreground border-t border-border">
        © {new Date().getFullYear()} {branding.channelName} — جميع الحقوق محفوظة
      </footer>
    </div>
  );
}
