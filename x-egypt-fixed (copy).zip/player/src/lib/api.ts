const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

export interface PublicServer {
  id: string;
  name: string;
}

export interface ManifestResponse {
  manifestUrl: string;
  type: "hls" | "dash" | "auto";
  licenseUrl: string | null;
  hasDrm: boolean;
}

export interface AdminServer {
  id: string;
  name: string;
  url: string;
  drmKeys?: Record<string, string>;
  referer?: string;
  origin?: string;
  userAgent?: string;
  headers?: Record<string, string>;
}

export async function fetchServers(): Promise<PublicServer[]> {
  const res = await fetch(`${BASE}/api/servers`);
  if (!res.ok) throw new Error("Failed to load servers");
  const data = (await res.json()) as { servers: PublicServer[] };
  return data.servers;
}

export async function fetchManifest(
  serverId: string,
): Promise<ManifestResponse> {
  const res = await fetch(`${BASE}/api/streams/${serverId}/manifest`);
  if (!res.ok) throw new Error("Failed to resolve stream");
  const data = (await res.json()) as ManifestResponse;
  return {
    ...data,
    manifestUrl: data.manifestUrl.startsWith("/")
      ? `${BASE}${data.manifestUrl}`
      : data.manifestUrl,
    licenseUrl: data.licenseUrl
      ? data.licenseUrl.startsWith("/")
        ? `${BASE}${data.licenseUrl}`
        : data.licenseUrl
      : null,
  };
}

export async function adminLogin(password: string): Promise<boolean> {
  const res = await fetch(`${BASE}/api/admin/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ password }),
  });
  return res.ok;
}

function authHeaders(): HeadersInit {
  const password = sessionStorage.getItem("admin_password") ?? "";
  return { "X-Admin-Password": password, "Content-Type": "application/json" };
}

export async function fetchAdminServers(): Promise<AdminServer[]> {
  const res = await fetch(`${BASE}/api/admin/servers`, {
    headers: authHeaders(),
  });
  if (!res.ok) throw new Error("Unauthorized");
  const data = (await res.json()) as { servers: AdminServer[] };
  return data.servers;
}

export async function saveAdminServer(server: AdminServer): Promise<void> {
  const res = await fetch(`${BASE}/api/admin/servers`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify(server),
  });
  if (!res.ok) {
    const data = (await res.json().catch(() => ({}))) as { error?: string };
    throw new Error(data.error ?? "Failed to save");
  }
}

export async function deleteAdminServer(id: string): Promise<void> {
  const res = await fetch(`${BASE}/api/admin/servers/${id}`, {
    method: "DELETE",
    headers: authHeaders(),
  });
  if (!res.ok) throw new Error("Failed to delete");
}
