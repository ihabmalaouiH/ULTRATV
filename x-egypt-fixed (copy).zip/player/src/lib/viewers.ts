import { useEffect, useState } from "react";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

function getSessionId(): string {
  let id = sessionStorage.getItem("xeg_session_id");
  if (!id) {
    id =
      typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    sessionStorage.setItem("xeg_session_id", id);
  }
  return id;
}

export function formatViewerCount(n: number): string {
  if (!Number.isFinite(n) || n < 0) return "0";
  if (n < 1000) return String(n);
  if (n < 1_000_000) {
    const v = n / 1000;
    if (v >= 100) return `${Math.floor(v)}K`;
    const s = v.toFixed(1);
    return `${s.endsWith(".0") ? s.slice(0, -2) : s}K`;
  }
  if (n < 1_000_000_000) {
    const v = n / 1_000_000;
    if (v >= 100) return `${Math.floor(v)}M`;
    const s = v.toFixed(1);
    return `${s.endsWith(".0") ? s.slice(0, -2) : s}M`;
  }
  const v = n / 1_000_000_000;
  const s = v.toFixed(1);
  return `${s.endsWith(".0") ? s.slice(0, -2) : s}B`;
}

export function useViewerCount(serverId: string | null): number {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!serverId) return;
    const sessionId = getSessionId();
    let cancelled = false;
    let timer: number | null = null;

    const ping = async () => {
      try {
        const res = await fetch(`${BASE}/api/viewers/${serverId}/ping`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ sessionId }),
        });
        if (cancelled || !res.ok) return;
        const data = (await res.json()) as { count: number };
        setCount(data.count);
      } catch {
        // ignore
      }
    };

    ping();
    timer = window.setInterval(ping, 12_000);

    const onUnload = () => {
      try {
        navigator.sendBeacon(
          `${BASE}/api/viewers/${serverId}/leave`,
          new Blob([JSON.stringify({ sessionId })], {
            type: "application/json",
          }),
        );
      } catch {
        // ignore
      }
    };
    window.addEventListener("beforeunload", onUnload);

    return () => {
      cancelled = true;
      if (timer) window.clearInterval(timer);
      window.removeEventListener("beforeunload", onUnload);
      onUnload();
    };
  }, [serverId]);

  return count;
}
